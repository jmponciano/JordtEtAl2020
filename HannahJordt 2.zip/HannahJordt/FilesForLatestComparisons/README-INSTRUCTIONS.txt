K(p1) vs K2(p1) * 
K(p2) vs K1(p2) *

K1(p1) vs K1(p1k) * 
K1(p1) vs K(p1) *

K2(p2) vs K2(p2k) # do the comparison with and without transfer 9.
		       # Up till transfer 6 the dynamics is the same but afterwards
	             # it begins to diverge???  Test for that separation after day 9.

K2(p2) vs K(p2) *