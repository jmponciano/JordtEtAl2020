# Table S2, EC28 comparison

source("CompareTools.R")

#First reading all the EC28 data
Fig5bAnc <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/Fig5bAnc_Jose.txt", header=TRUE))
datamatAnc <- Fig5bAnc

Fig5bEvo <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/Fig5bEvo_Jose.txt", header=TRUE))
datamatEv1 <- Fig5bEvo

#####  OK, testing Anc vs Ev_1 and Anc. vs Ev_2
Fig5bAncVsFig5bEvo <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,plot.Anc=TRUE,my.guess = c(0.5, 0.3, 0.05,log(1.5)))
> Fig5bAncVsFig5bEvo
$AncCIs.mat
                2.5%         MLE       97.5%
Beta0     -7.2586915 -5.22502301 -3.19135449
Beta1      0.7887937  1.54832405  2.30785434
Beta2     -0.1539492 -0.09119269 -0.02843621
log(Beta)  1.1237770  3.08000881  5.03624063

$EvCIs.mat
                2.5%         MLE        97.5%
Beta0     -7.0208606 -5.01590832 -3.010956013
Beta1      0.3860781  1.05557816  1.725078261
Beta2     -0.1037391 -0.05038979  0.002959512
log(Beta)  1.4115837  3.30700123  5.202418777

$JointCIs.mat
                2.5%         MLE       97.5%
Beta0     -6.4002932 -4.67797632 -2.95565940
Beta1      0.5681530  1.16174433  1.75533572
Beta2     -0.1101906 -0.06145894 -0.01272723
log(Beta)  0.9673914  1.91000372  2.85261600

$BIC.sep
[1] 125.3409

$BIC.joint
[1] 128.3598

$Best.model
[1] "Separate dynamics is best"


########
Fig5cAnc <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/Fig5cAnc_Jose.txt", header=TRUE))
datamatAnc <- Fig5cAnc

Fig5cEvo <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/Fig5cEvo_Jose.txt", header=TRUE))
datamatEv1 <- Fig5cEvo

#####  OK, testing Anc vs Ev_1 and Anc. vs Ev_2
Fig5cAncVsFig5cEvo <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,plot.Anc=TRUE)

$AncCIs.mat
                2.5%        MLE       97.5%
Beta0     -5.3901272 -3.9377848 -2.48544227
Beta1      0.8108091  1.3410316  1.87125414
Beta2     -0.1456933 -0.1004343 -0.05517533
log(Beta)  1.3388420  2.8179421  4.29704221

$EvCIs.mat
                 2.5%        MLE         97.5%
Beta0     -4.23616476 -2.9353390 -1.6345131892
Beta1      0.24186081  0.7503186  1.2587763708
Beta2     -0.09593978 -0.0483300 -0.0007202163
log(Beta)  0.84782473  1.9552363  3.0626479627

$JointCIs.mat
                2.5%        MLE       97.5%
Beta0     -4.4096527 -3.3884213 -2.36718979
Beta1      0.6345286  1.0198537  1.40517875
Beta2     -0.1065107 -0.0719446 -0.03737847
log(Beta)  1.2887277  2.1071491  2.92557047

$BIC.sep
[1] 154.3461

$BIC.joint
[1] 146.6045

$Best.model
[1] "Joint dynamics is best"



########
Fig5dAnc <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/Fig5dAnc_Jose.txt", header=TRUE))
datamatAnc <- Fig5dAnc

Fig5dEvo <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/Fig5dEvo_Jose.txt", header=TRUE))
datamatEv1 <- Fig5dEvo

#####  OK, testing Anc vs Ev_1 and Anc. vs Ev_2
Fig5dAncVsFig5dEvo <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,plot.Anc=TRUE)
Fig5dAncVsFig5dEvo
> Fig5dAncVsFig5dEvo
$AncCIs.mat
                2.5%         MLE        97.5%
Beta0     -3.1353790 -1.96002769 -0.784676330
Beta1      0.9560430  1.66528925  2.374535452
Beta2     -0.1791332 -0.09350066 -0.007868143
log(Beta) -0.4729712  0.46843833  1.409847887

$EvCIs.mat
                 2.5%         MLE        97.5%
Beta0      -8.5297126 -6.11074868 -3.691784730
Beta1       0.2034693  1.01175093  1.820032600
Beta2      -0.1233372 -0.05965253  0.004032187
log(Beta) -18.0787449  9.66664669 37.412038297

$JointCIs.mat
                2.5%         MLE        97.5%
Beta0     -2.8371335 -1.65024957 -0.463365658
Beta1      0.2096255  0.77362188  1.337618283
Beta2     -0.1198643 -0.06224865 -0.004633014
log(Beta) -1.7513211 -1.17810691 -0.604892686

$BIC.sep
[1] 136.9297

$BIC.joint
[1] 197.6125

$Best.model
[1] "Separate dynamics is best"



########
Fig5eAnc <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/Fig5eAnc_Jose.txt", header=TRUE))
datamatAnc <- Fig5eAnc

Fig5eEvo <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/Fig5eEvo_Jose.txt", header=TRUE))
datamatEv1 <- Fig5eEvo

#####  OK, testing Anc vs Ev_1 and Anc. vs Ev_2
Fig5eAncVsFig5eEvo <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,plot.Anc=TRUE)
Fig5eAncVsFig5eEvo

> Fig5eAncVsFig5eEvo
$AncCIs.mat
                2.5%         MLE      97.5%
Beta0     -2.0901717 -0.98610234 0.11796699
Beta1      0.8506549  1.69632844 2.54200200
Beta2     -0.2113014 -0.09665608 0.01798926
log(Beta) -1.1231335 -0.06530621 0.99252111

$EvCIs.mat
                 2.5%         MLE       97.5%
Beta0     -4.60295509 -3.60878250 -2.61460990
Beta1      0.58261062  0.96337972  1.34414882
Beta2     -0.08536149 -0.05213494 -0.01890839
log(Beta)  0.66173466  4.50164505  8.34155545

$JointCIs.mat
                 2.5%         MLE       97.5%
Beta0     -1.41639066 -0.57274624  0.27089817
Beta1      0.11515137  0.60463470  1.09411804
Beta2     -0.09515093 -0.03913348  0.01688398
log(Beta) -1.56061373 -0.99679704 -0.43298035

$BIC.sep
[1] 156.939

$BIC.joint
[1] 203.2675

$Best.model
[1] "Separate dynamics is best"
