# Table S2, EC28 comparison

source("CompareTools.R")

#First reading all the EC28 data
FigS8bAnc <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/FigS8bAnc_Jose.txt", header=TRUE))
datamatAnc <- FigS8bAnc

FigS8bEvo <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/FigS8bEvo_Jose.txt", header=TRUE))
datamatEv1 <- FigS8bEvo

#####  OK, testing Anc vs Ev_1 and Anc. vs Ev_2
FigS8bAncVsFigS8bEvo <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,plot.Anc=TRUE)
FigS8bAncVsFigS8bEvo

$AncCIs.mat
                2.5%        MLE       97.5%
Beta0     -5.3901272 -3.9377848 -2.48544227
Beta1      0.8108091  1.3410316  1.87125414
Beta2     -0.1456933 -0.1004343 -0.05517533
log(Beta)  1.3388420  2.8179421  4.29704221

$EvCIs.mat
                  2.5%         MLE       97.5%
Beta0      -5.38504941 -4.32584192 -3.26663443
Beta1       0.79228442  1.19255553  1.59282663
Beta2      -0.09953378 -0.06525736 -0.03098094
log(Beta) -10.94175118  8.34039438 27.62253994

$JointCIs.mat
                2.5%         MLE       97.5%
Beta0     -5.0965510 -3.99893723 -2.90132346
Beta1      0.8356411  1.23477933  1.63391758
Beta2     -0.1154804 -0.08154609 -0.04761174
log(Beta)  1.6102599  2.58030574  3.55035158

$BIC.sep
[1] 128.9495

$BIC.joint
[1] 132.8371

$Best.model
[1] "Separate dynamics is best"



########
FigS8cAnc <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/FigS8cAnc_Jose.txt", header=TRUE))
datamatAnc <- FigS8cAnc

FigS8cEvo <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/FigS8cEvo_Jose.txt", header=TRUE))
datamatEv1 <- FigS8cEvo

#####  OK, testing Anc vs Ev_1 and Anc. vs Ev_2
FigS8cAncVsFigS8cEvo <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,plot.Anc=TRUE)
FigS8cAncVsFigS8cEvo
> FigS8cAncVsFigS8cEvo
$AncCIs.mat
                2.5%         MLE       97.5%
Beta0     -7.2579181 -5.22443215 -3.19094620
Beta1      0.7886406  1.54810822  2.30757586
Beta2     -0.1539274 -0.09117528 -0.02842315
log(Beta)  1.1236472  3.07973341  5.03581967

$EvCIs.mat
                 2.5%         MLE      97.5%
Beta0      -6.7854069 -5.37444806 -3.9634892
Beta1       0.8850199  1.38583195  1.8866440
Beta2      -0.1138909 -0.07276835 -0.0316458
log(Beta) -21.4277967  9.51949462 40.4667859

$JointCIs.mat
                2.5%         MLE       97.5%
Beta0     -6.3620759 -5.15185711 -3.94163832
Beta1      0.9580294  1.39293195  1.82783452
Beta2     -0.1113086 -0.07561723 -0.03992585
log(Beta)  2.0949517  3.84257935  5.59020702

$BIC.sep
[1] 112.3508

$BIC.joint
[1] 105.352

$Best.model
[1] "Joint dynamics is best"


########
FigS8dAnc <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/FigS8dAnc_Jose.txt", header=TRUE))
datamatAnc <- FigS8dAnc

FigS8dEvo <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/FigS8dEvo_Jose.txt", header=TRUE))
datamatEv1 <- FigS8dEvo

#####  OK, testing Anc vs Ev_1 and Anc. vs Ev_2
FigS8dAncVsFigS8dEvo <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,plot.Anc=TRUE)
FigS8dAncVsFigS8dEvo

$AncCIs.mat
                2.5%         MLE      97.5%
Beta0     -2.0901717 -0.98610234 0.11796699
Beta1      0.8506549  1.69632844 2.54200200
Beta2     -0.2113014 -0.09665608 0.01798926
log(Beta) -1.1231335 -0.06530621 0.99252111

$EvCIs.mat
                 2.5%         MLE        97.5%
Beta0     -5.23666816 -4.08546091 -2.934253650
Beta1      0.46789449  0.88188009  1.295865685
Beta2     -0.07657904 -0.04165473 -0.006730425
log(Beta) -0.34233626  4.70442369  9.751183635

$JointCIs.mat
                 2.5%         MLE       97.5%
Beta0     -1.53198242 -0.64391064  0.24416114
Beta1      0.06195498  0.56252224  1.06308951
Beta2     -0.09382555 -0.03704861  0.01972833
log(Beta) -1.71069813 -1.14868167 -0.58666521

$BIC.sep
[1] 155.7691

$BIC.joint
[1] 203.4025

$Best.model
[1] "Separate dynamics is best"


########
FigS8eAnc <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/FigS8eAnc_Jose.txt", header=TRUE))
datamatAnc <- FigS8eAnc

FigS8eEvo <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS4/FigS8eEvo_Jose.txt", header=TRUE))
datamatEv1 <- FigS8eEvo

#####  OK, testing Anc vs Ev_1 and Anc. vs Ev_2
Fig5eAncVsFig5eEvo <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,plot.Anc=TRUE)
Fig5eAncVsFig5eEvo

> Fig5eAncVsFig5eEvo
$AncCIs.mat
                2.5%         MLE        97.5%
Beta0     -3.1353790 -1.96002769 -0.784676330
Beta1      0.9560430  1.66528925  2.374535452
Beta2     -0.1791332 -0.09350066 -0.007868143
log(Beta) -0.4729712  0.46843833  1.409847887

$EvCIs.mat
                2.5%        MLE      97.5%
Beta0     -82.621204 -82.621204 -82.621204
Beta1     -19.232972 -19.232972 -19.232972
Beta2       2.742446   2.742446   2.742446
log(Beta) 158.330147 158.330147 158.330147

$JointCIs.mat
                2.5%         MLE        97.5%
Beta0     -3.0214862 -1.75206736 -0.482648548
Beta1      0.1262178  0.72936973  1.332521647
Beta2     -0.1156227 -0.05529253  0.005037627
log(Beta) -1.8673228 -1.27819797 -0.689073141

$BIC.sep
[1] 103.1508

$BIC.joint
[1] 191.1613

$Best.model
[1] "Separate dynamics is best"

