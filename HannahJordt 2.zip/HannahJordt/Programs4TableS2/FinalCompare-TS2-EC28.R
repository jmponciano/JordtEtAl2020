# Table S2, EC28 comparison

source("CompareTools.R")

#First reading all the EC28 data
EC28Anc <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/EC28Anc_Jose.txt", header=TRUE))
datamatAnc <- EC28Anc

EC28Ev_1 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/EC28_1_Jose.txt", header=TRUE))
datamatEv1 <- EC28Ev_1

EC28Ev_4 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/EC28_4_Jose.txt", header=TRUE))
datamatEv4 <- EC28Ev_4


#####  OK, testing Anc vs Ev_1 and Anc. vs Ev_2
EC28AncVsEC28_1 <- joint.vs.sep.fit(datamatAnc=datamatAnc[1:3,], datamatEv = datamatEv1[1:3,], plot.Anc=TRUE)
EC28AncVsEC28_4 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv4)

> EC28AncVsEC28_1
$AncCIs.mat
                2.5%         MLE       97.5%
Beta0     -4.0528418 -2.45997117 -0.86710057
Beta1      0.2746634  0.93498937  1.59531536
Beta2     -0.1311193 -0.07049706 -0.00987485
log(Beta)  0.1252930  1.12230128  2.11930958

$EvCIs.mat
                 2.5%         MLE       97.5%
Beta0     -5.31703480 -4.18234878 -3.04766277
Beta1      0.22093774  0.63626131  1.05158489
Beta2     -0.06264554 -0.02735963  0.00792627
log(Beta)  8.68202866  8.68332279  8.68461691

$JointCIs.mat
                 2.5%         MLE        97.5%
Beta0     -3.76417834 -2.62222133 -1.480264317
Beta1      0.14604992  0.61307819  1.080106453
Beta2     -0.08167935 -0.03751366  0.006652033
log(Beta)  0.35833693  1.04840080  1.738464683

$BIC.sep
[1] 152.0102

$BIC.joint
[1] 166.8182

$Best.model
[1] "Separate dynamics is best"

> EC28AncVsEC28_4
$AncCIs.mat
                2.5%         MLE       97.5%
Beta0     -4.0528418 -2.45997117 -0.86710057
Beta1      0.2746634  0.93498937  1.59531536
Beta2     -0.1311193 -0.07049706 -0.00987485
log(Beta)  0.1252930  1.12230128  2.11930958

$EvCIs.mat
               2.5%        MLE    97.5%
Beta0     -369.0339 -15.400627 338.2327
Beta1           NaN  31.268182      NaN
Beta2           NaN  -9.267532      NaN
log(Beta) -226.1363  12.818083 251.7725

$JointCIs.mat
                 2.5%         MLE      97.5%
Beta0     -3.54714595 -2.15714983 -0.7671537
Beta1     -0.29340276  0.34431259  0.9820280
Beta2     -0.09650213 -0.03036437  0.0357734
log(Beta) -1.11640088 -0.31559952  0.4852018

$BIC.sep
[1] 107.9838

$BIC.joint
[1] 137.003

$Best.model
[1] "Separate dynamics is best"




########## Left-over code, don't use ######

######## Plotting the mles of the curve and the observed proportions
nreps <- 3
days <- datamat[,1] # First column should be the 'Days'
repdays <- rep(days,nreps)
counts  <- as.vector(datamat[,2:(nreps+1)])
Ntrials <- as.vector(datamat[,(nreps+2):(nreps*2+1)])
obs.props <- counts/Ntrials
betas.mles <- CIs.mat[1:3,2]
cont.days <- seq(0,max(days), by=0.1)
mle.props <- 1/(1+ exp(-(betas.mles[1]+betas.mles[2]*cont.days +betas.mles[3]*cont.days^2)))
betas.cis1 <- CIs.mat[1:3,1]
betas.cis2 <- CIs.mat[1:3,3]
cis1.props <- 1/(1+ exp(-(betas.cis1[1]+betas.cis1[2]*cont.days +betas.cis1[3]*cont.days^2)))
cis2.props <- 1/(1+ exp(-(betas.cis2[1]+betas.cis2[2]*cont.days +betas.cis2[3]*cont.days^2)))

plot(repdays,obs.props, pch=16)
points(cont.days,mle.props, type="l", col="red", lwd=2)
points(cont.days,cis1.props, col="dark grey", lwd=2, lty=2, type="l")
points(cont.days,cis2.props, col="dark grey", lwd=2, lty=2, type="l")
