EC stands for E coli (or "E" in table S2)
KP stands for K pnumoniae (or "K" in table S2)
28 stands for the plasmid p1
29 stands for the plasmid p2
Anc obviously means ancestor
Additional numbers besides 28 and 29 represent the replicate numbers


Do the following comparisons corresponding to the table S2 results:

EC28Anc_Jose.txt vs EC28_1_Jose and EC28_4_Jose


EC29Anc_Jose.txt vs EC29_1_Jose to EC29_6_Jose

And repeat with KP ancestor with plasmid 1 and with plasmid 2 vs replicates 1 to 6

