
Do the following comparisons presented in the table S4:

Fig5XAnc_Jose vs Fig5XEvo_Jose and also 

FigS8XAnc_Jose vs FigS8XEvo_Jose

