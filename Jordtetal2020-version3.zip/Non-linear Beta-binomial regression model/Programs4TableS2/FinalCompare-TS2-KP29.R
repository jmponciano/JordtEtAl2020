# Table S2, KP29 comparison


source("CompareTools.R")

#First reading all the EC29 data
KP29Anc <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/KP29Anc.txt", header=TRUE))
datamatAnc <- KP29Anc

KP29Ev_1 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/KP29_1.txt", header=TRUE))
datamatEv1 <- KP29Ev_1

KP29Ev_2 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/KP29_2.txt", header=TRUE))
datamatEv2 <- KP29Ev_2

KP29Ev_3 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/KP29_3.txt", header=TRUE))
datamatEv3 <- KP29Ev_3

KP29Ev_4 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/KP29_4.txt", header=TRUE))
datamatEv4 <- KP29Ev_4

KP29Ev_5 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/KP29_5.txt", header=TRUE))
datamatEv5 <- KP29Ev_5

KP29Ev_6 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/KP29_6.txt", header=TRUE))
datamatEv6 <- KP29Ev_6


#####  OK, testing Anc vs Ev_1 all the way to Anc. vs Ev_6
KP29AncVsKP29_1 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1)
KP29AncVsKP29_2 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv2)
KP29AncVsKP29_3 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv3, my.method="BFGS")
KP29AncVsKP29_4 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv4)
KP29AncVsKP29_5 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv5)
KP29AncVsKP29_6 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv6)

> KP29AncVsKP29_1 
$AncCIs.mat
                2.5%        MLE        97.5%
Beta0     -6.2779350 -3.5570679 -0.836200837
Beta1      0.7031257  1.8485883  2.994050889
Beta2     -0.2170135 -0.1055874  0.005838601
log(Beta) -1.2345304  0.1484992  1.531528766

$EvCIs.mat
                2.5%         MLE        97.5%
Beta0     -6.0343015 -4.28028352 -2.526265507
Beta1      0.2254250  0.85243252  1.479440049
Beta2     -0.1124912 -0.05785353 -0.003215838
log(Beta)  1.5934098  2.93338974  4.273369721

$JointCIs.mat
                2.5%         MLE       97.5%
Beta0     -5.0903156 -3.00248994 -0.91466426
Beta1      0.3737057  1.18440339  1.99510114
Beta2     -0.1633011 -0.08915017 -0.01499927
log(Beta) -1.6918540 -1.02644920 -0.36104444

$BIC.sep
[1] 117.4437

$BIC.joint
[1] 147.2844

$Best.model
[1] "Separate dynamics is best"

> KP29AncVsKP29_2
$AncCIs.mat
                2.5%        MLE        97.5%
Beta0     -6.2779350 -3.5570679 -0.836200837
Beta1      0.7031257  1.8485883  2.994050889
Beta2     -0.2170135 -0.1055874  0.005838601
log(Beta) -1.2345304  0.1484992  1.531528766

$EvCIs.mat
                2.5%         MLE        97.5%
Beta0     -8.9808365 -6.22231047 -3.463784430
Beta1      0.2078616  1.21140472  2.214947799
Beta2     -0.1678155 -0.08546895 -0.003122385
log(Beta)  1.0862930  4.93088709  8.775481207

$JointCIs.mat
                2.5%         MLE      97.5%
Beta0     -5.6419150 -3.27971658 -0.9175182
Beta1      0.3389388  1.25764164  2.1763445
Beta2     -0.1782355 -0.09693509 -0.0156347
log(Beta) -1.8439690 -1.16963331 -0.4952976

$BIC.sep
[1] 96.4624

$BIC.joint
[1] 132.7294

$Best.model
[1] "Separate dynamics is best"

> KP29AncVsKP29_3
$AncCIs.mat
                2.5%        MLE        97.5%
Beta0     -6.2779350 -3.5570679 -0.836200837
Beta1      0.7031257  1.8485883  2.994050889
Beta2     -0.2170135 -0.1055874  0.005838601
log(Beta) -1.2345304  0.1484992  1.531528766

$EvCIs.mat
                 2.5%          MLE       97.5%
Beta0             NaN -27.72555576         NaN
Beta1     -0.08212324  -0.08212324 -0.08212324
Beta2     -4.88315256  -4.88315256 -4.88315256
log(Beta)         NaN -18.38394527         NaN

$JointCIs.mat
                2.5%         MLE       97.5%
Beta0     -6.4524621 -3.37395102 -0.29543993
Beta1     -0.1897520  1.00308913  2.19593021
Beta2     -0.1850986 -0.07869633  0.02770594
log(Beta) -3.0133335 -2.10662753 -1.19992157

$BIC.sep
[1] 62.40112

$BIC.joint
[1] 91.71704

$Best.model
[1] "Separate dynamics is best"

> KP29AncVsKP29_4
$AncCIs.mat
                2.5%        MLE        97.5%
Beta0     -6.2779350 -3.5570679 -0.836200837
Beta1      0.7031257  1.8485883  2.994050889
Beta2     -0.2170135 -0.1055874  0.005838601
log(Beta) -1.2345304  0.1484992  1.531528766

$EvCIs.mat
                2.5%         MLE       97.5%
Beta0     -8.1065920 -5.72962110 -3.35265022
Beta1      0.2072016  0.97773602  1.74827044
Beta2     -0.1039140 -0.04450344  0.01490713
log(Beta)  1.0296203  4.58413610  8.13865192

$JointCIs.mat
                2.5%         MLE        97.5%
Beta0     -5.9046468 -3.44107839 -0.977509956
Beta1      0.2384471  1.18170102  2.124954942
Beta2     -0.1625114 -0.07849797  0.005515479
log(Beta) -1.7328657 -1.05027976 -0.367693799

$BIC.sep
[1] 106.7046

$BIC.joint
[1] 140.4721

$Best.model
[1] "Separate dynamics is best"

> KP29AncVsKP29_5
$AncCIs.mat
                2.5%        MLE        97.5%
Beta0     -6.2779350 -3.5570679 -0.836200837
Beta1      0.7031257  1.8485883  2.994050889
Beta2     -0.2170135 -0.1055874  0.005838601
log(Beta) -1.2345304  0.1484992  1.531528766

$EvCIs.mat
                 2.5%         MLE       97.5%
Beta0     -80.6781935 -80.6781935 -80.6781935
Beta1       6.1359855   6.1359855   6.1359855
Beta2       0.4704451   0.4704451   0.4704451
log(Beta) 103.0281435 103.0281435 103.0281435

$JointCIs.mat
                2.5%         MLE       97.5%
Beta0     -5.6082127 -3.31505189 -1.02189113
Beta1      0.3811758  1.27457196  2.16796811
Beta2     -0.1724133 -0.09215742 -0.01190151
log(Beta) -1.6352628 -0.96748792 -0.29971304

$BIC.sep
[1] 62.40112

$BIC.joint
[1] 143.2111

$Best.model
[1] "Separate dynamics is best"

> KP29AncVsKP29_6
$AncCIs.mat
                2.5%        MLE        97.5%
Beta0     -6.2779350 -3.5570679 -0.836200837
Beta1      0.7031257  1.8485883  2.994050889
Beta2     -0.2170135 -0.1055874  0.005838601
log(Beta) -1.2345304  0.1484992  1.531528766

$EvCIs.mat
                2.5%        MLE      97.5%
Beta0     -72.902266 -72.902266 -72.902266
Beta1      46.880262  46.880262  46.880262
Beta2      -9.483651  -9.483651  -9.483651
log(Beta) 506.970481 506.970481 506.970481

$JointCIs.mat
                2.5%         MLE        97.5%
Beta0     -5.6029287 -3.24450987 -0.886091055
Beta1      0.2036677  1.10644516  2.009222607
Beta2     -0.1563021 -0.07546872  0.005364642
log(Beta) -1.8380853 -1.15480738 -0.471529452

$BIC.sep
[1] 62.40112

$BIC.joint
[1] 140.2492

$Best.model
[1] "Separate dynamics is best"
