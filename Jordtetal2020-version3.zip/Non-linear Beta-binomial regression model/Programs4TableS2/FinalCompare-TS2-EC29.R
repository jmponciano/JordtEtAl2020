# Table S2, EC29 comparison
source("CompareTools.R")


#First reading all the EC29 data
EC29Anc <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/EC29Anc.txt", header=TRUE))
datamatAnc <- EC29Anc

EC29Ev_1 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/EC29_1.txt", header=TRUE))
datamatEv1 <- EC29Ev_1

EC29Ev_2 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/EC29_2.txt", header=TRUE))
datamatEv2 <- EC29Ev_2

EC29Ev_3 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/EC29_3.txt", header=TRUE))
datamatEv3 <- EC29Ev_3

EC29Ev_4 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/EC29_4.txt", header=TRUE))
datamatEv4 <- EC29Ev_4

EC29Ev_5 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/EC29_5.txt", header=TRUE))
datamatEv5 <- EC29Ev_5

EC29Ev_6 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/EC29_6.txt", header=TRUE))
datamatEv6 <- EC29Ev_6


#####  OK, testing Anc vs Ev_1 all the way to Anc. vs Ev_6
EC29AncVsEC29_1 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,my.method="Nelder-Mead",my.guess = c(0.5, 0.3, 0.05,log(1.5)))
EC29AncVsEC29_2 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv2,my.guess = c(0.5, 0.6, 0.005,log(3.5)))

EC29AncVsEC29_3 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv3, my.method="Nelder-Mead",my.guess = c(0.05, 0.3, 0.05,log(1.5)), plot.Anc=TRUE)
#EC29AncVsEC29_3 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv3, my.method="Nelder-Mead",my.guess = c(0.5, 0.3,log(1.5)))
#EC29AncVsEC29_3 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv3, my.method="BFGS",my.guess = c(0.05, 0.003))

EC29AncVsEC29_4 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv4,my.guess = c(0.5, 0.6, 0.00000005,log(2.5)))
EC29AncVsEC29_5 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv5,my.guess = c(0.2, 0.3, 0.005,log(1.5)), my.method="Nelder-Mead")
EC29AncVsEC29_6 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv6,my.guess = c(0.5, 0.6, 0.005,log(3.5)))

> EC29AncVsEC29_1
$AncCIs.mat
                 2.5%         MLE      97.5%
Beta0     -11.1734145 -6.09221073 -1.0110070
Beta1      -0.9573827  0.73610896  2.4296006
Beta2      -0.1591784 -0.02368745  0.1118035
log(Beta)   0.2766776  1.80608737  3.3354971

$EvCIs.mat
                 2.5%         MLE      97.5%
Beta0     -3.03977655 -1.73848676 -0.4371970
Beta1     -1.33023104 -0.60003321  0.1301646
Beta2      0.01483825  0.09001101  0.1651838
log(Beta)  0.08982283  1.16631358  2.2428043

$JointCIs.mat
                  2.5%         MLE      97.5%
Beta0     -4.048154657 -2.73458196 -1.4210093
Beta1     -0.800853090 -0.20084100  0.3991711
Beta2     -0.009985281  0.04930038  0.1085860
log(Beta)  0.134335914  0.99317298  1.8520100

$BIC.sep
[1] 124.2528

$BIC.joint
[1] 121.5925

$Best.model
[1] "Joint dynamics is best"

> EC29AncVsEC29_2
$AncCIs.mat
                 2.5%         MLE      97.5%
Beta0     -11.1734145 -6.09221073 -1.0110070
Beta1      -0.9573827  0.73610896  2.4296006
Beta2      -0.1591784 -0.02368745  0.1118035
log(Beta)   0.2766776  1.80608737  3.3354971

$EvCIs.mat
                2.5%        MLE      97.5%
Beta0     -275.74465 -275.74465 -275.74465
Beta1     -134.57036 -134.57036 -134.57036
Beta2       18.58615   18.58615   18.58615
log(Beta)  638.22630  638.22630  638.22630

$JointCIs.mat
                 2.5%         MLE       97.5%
Beta0     -13.8904930 -7.93863957 -1.98678611
Beta1      -0.5148809  1.35867292  3.23222675
Beta2      -0.2201788 -0.07911506  0.06194868
log(Beta)   0.6902262  1.83606609  2.98190600

$BIC.sep
[1] 64.3091

$BIC.joint
[1] 79.66147

$Best.model
[1] "Separate dynamics is best"

> EC29AncVsEC29_3
$AncCIs.mat
                 2.5%         MLE      97.5%
Beta0     -10.9881055 -6.02176686 -1.0554282
Beta1      -0.9551894  0.70745827  2.3701060
Beta2      -0.1549639 -0.02136036  0.1122432
log(Beta)   0.2848258  1.81160793  3.3383900

$EvCIs.mat
                 2.5%         MLE       97.5%
Beta0     -31.0027081 -30.7958631 -30.5890180
Beta1       6.4754384   7.2578121   8.0401858
Beta2      -0.5612433  -0.4667164  -0.3721894
log(Beta)   0.5869570   4.3535754   8.1201939

$JointCIs.mat
                 2.5%         MLE       97.5%
Beta0     -12.9236237 -7.41549669 -1.90736964
Beta1      -0.6469797  1.10320509  2.85338989
Beta2      -0.1900452 -0.05683468  0.07637582
log(Beta)   0.6765405  1.84238826  3.00823597

$BIC.sep
[1] 82.82043

$BIC.joint
[1] 76.95906

> EC29AncVsEC29_4
$AncCIs.mat
               2.5%       MLE     97.5%
Beta0     -84.70689 -84.70689 -84.70689
Beta1     -54.52289 -54.52289 -54.52289
Beta2       6.66531   6.66531   6.66531
log(Beta) 240.29894 240.29894 240.29894

$EvCIs.mat
                2.5%        MLE      97.5%
Beta0      -8.715174  -8.714771  -8.714369
Beta1     -13.073811 -13.073023 -13.072235
Beta2       1.517776   1.517849   1.517922
log(Beta)  39.760773  39.761827  39.762881

$JointCIs.mat
                 2.5%         MLE       97.5%
Beta0     -6.05679153 -4.14581998 -2.23484842
Beta1     -0.72616090  0.07380462  0.87377013
Beta2     -0.06418155  0.01331003  0.09080161
log(Beta)  0.33404687  1.54695249  2.75985812

$BIC.sep
[1] 71.77178

$BIC.joint
[1] 80.16868

$Best.model
[1] "Separate dynamics is best"


> EC29AncVsEC29_5
$AncCIs.mat
                 2.5%        MLE      97.5%
Beta0     -11.0100995 -6.0290685 -1.0480375
Beta1      -0.9558169  0.7105093  2.3768355
Beta2      -0.1553769 -0.0215691  0.1122387
log(Beta)   0.2795163  1.8087404  3.3379644

$EvCIs.mat
                2.5%         MLE       97.5%
Beta0     -6.6485344 -4.67167243 -2.69481042
Beta1     -0.4412541  0.56012431  1.56150276
Beta2     -0.1919948 -0.07691907  0.03815668
log(Beta)  1.2128047  4.71880970  8.22481466

$JointCIs.mat
                2.5%        MLE       97.5%
Beta0     -6.2274206 -4.3068099 -2.38619916
Beta1     -0.3204221  0.4423454  1.20511279
Beta2     -0.1018189 -0.0293109  0.04319707
log(Beta)  0.5889672  1.6996664  2.81036555

$BIC.sep
[1] 88.43639

$BIC.joint
[1] 90.84641

$Best.model
[1] "Separate dynamics is best"




> EC29AncVsEC29_6
$AncCIs.mat
                 2.5%         MLE      97.5%
Beta0     -11.1734145 -6.09221073 -1.0110070
Beta1      -0.9573827  0.73610896  2.4296006
Beta2      -0.1591784 -0.02368745  0.1118035
log(Beta)   0.2766776  1.80608737  3.3354971

$EvCIs.mat
                2.5%        MLE      97.5%
Beta0     13.7550682 13.7550682 13.7550682
Beta1     -0.4203965 -0.4203965 -0.4203965
Beta2     -7.4651016 -7.4651016 -7.4651016
log(Beta) 94.6325207 94.6325207 94.6325207

$JointCIs.mat
                2.5%         MLE      97.5%
Beta0     -6.2736718 -4.14267489 -2.0116779
Beta1     -0.8627641  0.03964408  0.9420523
Beta2     -0.0719108  0.01605217  0.1040151
log(Beta) -0.1265021  1.21219450  2.5508911

$BIC.sep
[1] 64.3091

$BIC.joint
[1] 72.90617

$Best.model
[1] "Separate dynamics is best"

######## For the third clone, where the joint dynamics is best:  simulate data with different sampling schemes
######## and with different dynamics and compute the proportion of times the correct conclusion is reached 

mles.anc3 <- EC29AncVsEC29_3$AncCIs.mat[,2]
mles.anc3[4] <- exp(mles.anc3[4])
mles.evol3 <- EC29AncVsEC29_3$EvCIs.mat[,2]
mles.evol3[4] <- exp(mles.evol3[4])
days <- seq(0,9, by=0.01)
anc3.p.x   <- 1/(1+ exp(-(mles.anc3[1]+mles.anc3[2]*days  + mles.anc3[3]*days^2)))
ev3.p.x   <- 1/(1+ exp(-(mles.evol3[1]+mles.evol3[2]*days  + mles.evol3[3]*days^2)))
plot(days, anc3.p.x, ylim=c(0,1), type="l", lwd=2, col="blue")
points(days, ev3.p.x, ylim=c(0,1), type="l", lwd=2, col="blue")
 
B <- 100
true.guess.count <- rep(0,B)
days4sim <- seq(0,9,by=3) # 0:9 # 0.75 % of the time correct
reps4sim <- 3
Dforsim <- matrix(50,nrow=length(days4sim), ncol=reps4sim)

for(i in 1:B){
	
	anc.sim <- bblogist.sim(mles=mles.anc3, days=days4sim, Dmat=Dforsim)
	ev.sim  <- bblogist.sim(mles=mles.evol3, days=days4sim, Dmat=Dforsim)
	
	simtest <- joint.vs.sep.fit(datamatAnc=anc.sim, datamatEv = ev.sim, my.method="Nelder-Mead",my.guess = c(0.05, 0.3, 0.05,log(1.5)), plot.Anc=FALSE)
	
	if(simtest$Best.model=="Separate dynamics is best"){true.guess.count[i]<- 1}
	
}
sum(true.guess.count)/B
