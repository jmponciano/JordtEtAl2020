# Table S2, KP28 comparison

source("CompareTools.R")


#First reading all the EC29 data
KP28Anc <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/KP28Anc.txt", header=TRUE))
datamatAnc <- KP28Anc

KP28Ev_1 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/KP28_1.txt", header=TRUE))
datamatEv1 <- KP28Ev_1

KP28Ev_2 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/KP28_2.txt", header=TRUE))
datamatEv2 <- KP28Ev_2

KP28Ev_3 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/KP28_3.txt", header=TRUE))
datamatEv3 <- KP28Ev_3

KP28Ev_4 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/KP28_4.txt", header=TRUE))
datamatEv4 <- KP28Ev_4

KP28Ev_5 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/KP28_5.txt", header=TRUE))
datamatEv5 <- KP28Ev_5

KP28Ev_6 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TableS2/KP28_6.txt", header=TRUE))
datamatEv6 <- KP28Ev_6


#####  OK, testing Anc vs Ev_1 all the way to Anc. vs Ev_6
KP28AncVsKP28_1 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,my.guess = c(0.5, 0.6, 0.005,log(0.5)))
KP28AncVsKP28_2 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv2,my.guess = c(0.5, 0.6, 0.05,log(1.5)), my.method="Nelder-Mead")
KP28AncVsKP28_3 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv3,my.guess = c(0.5, 0.6, 0.005,log(0.05)))
KP28AncVsKP28_4 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv4,my.guess = c(0.5, 0.6, 0.005,log(0.5)))
KP28AncVsKP28_5 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv5,my.guess = c(0.5, 0.6, 0.005,log(0.5)))
KP28AncVsKP28_6 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv6,my.guess = c(0.5, 0.6, 0.005,log(0.5)))


> KP28AncVsKP28_1
$AncCIs.mat
                 2.5%       MLE      97.5%
Beta0       -5.832547 -3.850033  -1.867519
Beta1     -116.432491  1.714373 119.861237
Beta2      -39.096832  0.288742  39.674316
log(Beta) -317.426824 10.660825 338.748473

$EvCIs.mat
                2.5%        MLE       97.5%
Beta0     -5.7581482 -4.4703289 -3.18250967
Beta1      0.6960363  1.1627370  1.62943763
Beta2     -0.1257173 -0.0869672 -0.04821706
log(Beta) 11.0528046 11.0529576 11.05311052

$JointCIs.mat
                2.5%         MLE        97.5%
Beta0     -3.6238897 -1.92534030 -0.226790924
Beta1      0.3068927  1.05296308  1.799033491
Beta2     -0.1548639 -0.08193182 -0.008999699
log(Beta) -2.4298356 -1.67302038 -0.916205195

$BIC.sep
[1] 81.81201

$BIC.joint
[1] 133.8579

$Best.model
[1] "Separate dynamics is best"

> KP28AncVsKP28_2
$AncCIs.mat
               2.5%       MLE    97.5%
Beta0           NaN -3.138037      NaN
Beta1     -94.93806  1.397234 97.73253
Beta2     -31.80335  0.309427 32.42220
log(Beta)       NaN  1.675981      NaN

$EvCIs.mat
                2.5%         MLE      97.5%
Beta0     -9.1733183 -5.30254814 -1.4317779
Beta1     -1.7738887 -0.18975622  1.3943763
Beta2     -0.0940810  0.05383013  0.2017413
log(Beta)  0.2981205  2.76041788  5.2227153

$JointCIs.mat
                 2.5%        MLE       97.5%
Beta0     -3.21040984 -1.4890840  0.23224186
Beta1     -0.40073002  0.3936110  1.18795206
Beta2     -0.09914573 -0.0193765  0.06039274
log(Beta) -3.72473136 -2.7281272 -1.73152296

$BIC.sep
[1] 64.65918

$BIC.joint
[1] 90.06624

$Best.model
[1] "Separate dynamics is best"

> KP28AncVsKP28_3
$AncCIs.mat
                 2.5%       MLE      97.5%
Beta0       -5.832547 -3.850033  -1.867519
Beta1     -116.432491  1.714373 119.861237
Beta2      -39.096832  0.288742  39.674316
log(Beta) -317.426824 10.660825 338.748473

$EvCIs.mat
                2.5%         MLE         97.5%
Beta0     -6.5335710 -3.66306287 -0.7925547248
Beta1      0.1947499  1.26147995  2.3282099727
Beta2     -0.1861086 -0.09261656  0.0008754768
log(Beta) -0.8798131  0.20372983  1.2872727131

$JointCIs.mat
                2.5%         MLE        97.5%
Beta0     -3.6417425 -1.90830901 -0.174875527
Beta1      0.3665679  1.15116485  1.935761796
Beta2     -0.1656935 -0.08733952 -0.008985524
log(Beta) -2.5354612 -1.75780198 -0.980142778

$BIC.sep
[1] 110.6712

$BIC.joint
[1] 124.8289

$Best.model
[1] "Separate dynamics is best"

> KP28AncVsKP28_4
$AncCIs.mat
                 2.5%       MLE      97.5%
Beta0       -5.832547 -3.850033  -1.867519
Beta1     -116.432491  1.714373 119.861237
Beta2      -39.096832  0.288742  39.674316
log(Beta) -317.426824 10.660825 338.748473

$EvCIs.mat
                 2.5%         MLE       97.5%
Beta0     -7.03948268 -4.86588402 -2.69228537
Beta1      0.09073107  0.81032266  1.52991424
Beta2     -0.05532305  0.00458171  0.06448647
log(Beta)  1.19786097  2.86848324  4.53910551

$JointCIs.mat
                 2.5%         MLE       97.5%
Beta0     -3.61567983 -1.98981412 -0.36394840
Beta1     -0.01885368  0.74179204  1.50243775
Beta2     -0.10048169 -0.01740727  0.06566715
log(Beta) -2.17728739 -1.38255234 -0.58781730

$BIC.sep
[1] 85.32871

$BIC.joint
[1] 116.1479

$Best.model
[1] "Separate dynamics is best"

> KP28AncVsKP28_5
$AncCIs.mat
                 2.5%       MLE      97.5%
Beta0       -5.832547 -3.850033  -1.867519
Beta1     -116.432491  1.714373 119.861237
Beta2      -39.096832  0.288742  39.674316
log(Beta) -317.426824 10.660825 338.748473

$EvCIs.mat
                  2.5%        MLE      97.5%
Beta0     -13.92677806 -7.7406339 -1.5544898
Beta1       0.04973654  2.9976972  5.9456579
Beta2      -0.44913383 -0.1427119  0.1637099
log(Beta) -42.89418731  8.6067299 60.1076470

$JointCIs.mat
                2.5%        MLE      97.5%
Beta0     -4.7016682 -2.6268333 -0.5519984
Beta1     -0.1015925  1.1585857  2.4187639
Beta2     -0.1620805  0.0375824  0.2372453
log(Beta) -2.0115810 -0.8706208  0.2703395

$BIC.sep
[1] 59.13933

$BIC.joint
[1] 66.99493

$Best.model
[1] "Separate dynamics is best"

> KP28AncVsKP28_6
$AncCIs.mat
                 2.5%       MLE      97.5%
Beta0       -5.832547 -3.850033  -1.867519
Beta1     -116.432491  1.714373 119.861237
Beta2      -39.096832  0.288742  39.674316
log(Beta) -317.426824 10.660825 338.748473

$EvCIs.mat
               2.5%       MLE     97.5%
Beta0     -64.87052 -64.87052 -64.87052
Beta1     -93.84892 -93.84892 -93.84892
Beta2      11.55220  11.55220  11.55220
log(Beta) 115.98018 115.98018 115.98018

$JointCIs.mat
                 2.5%        MLE      97.5%
Beta0     -3.36571029 -1.6036584  0.1583935
Beta1     -0.67506073  0.1440724  0.9632056
Beta2     -0.06250656  0.0220468  0.1066002
log(Beta) -3.62194906 -2.6198174 -1.6176856

$BIC.sep
[1] 39.51307

$BIC.joint
[1] 92.00393

$Best.model
[1] "Separate dynamics is best"

> 
