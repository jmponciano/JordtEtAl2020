# Tables S5 and S9 comparisons

source("CompareTools.R")

####  First Kp1 vs K2p1
Kp1 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TablesS5andS9/K(p1) aka KP28Anc.txt", header=TRUE))
datamatAnc <- Kp1

K2p1 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TablesS5andS9/K2(p1).txt", header=TRUE))
datamatEv1 <- K2p1

Kp1VsK2p1 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,plot.Anc=FALSE,my.guess = c(0.5, 0.6, 0.005,log(0.5)))
Kp1VsK2p1

> Kp1VsK2p1
$AncCIs.mat
                 2.5%       MLE      97.5%
Beta0       -5.832547 -3.850033  -1.867519
Beta1     -116.432491  1.714373 119.861237
Beta2      -39.096832  0.288742  39.674316
log(Beta) -317.426824 10.660825 338.748473

$EvCIs.mat
                 2.5%          MLE      97.5%
Beta0     -3.88915611 -2.689609524 -1.4900629
Beta1      0.23173841  0.744602971  1.2574675
Beta2     -0.06046745 -0.006762524  0.0469424
log(Beta)  0.52461795  2.008185675  3.4917534

$JointCIs.mat
                 2.5%         MLE       97.5%
Beta0     -2.84196388 -1.52847977 -0.21499566
Beta1      0.12956415  0.79577537  1.46198659
Beta2     -0.09501235 -0.01779089  0.05943057
log(Beta) -1.85369326 -1.01896851 -0.18424376

$BIC.sep
[1] 95.6847

$BIC.joint
[1] 114.6691

$Best.model
[1] "Separate dynamics is best"


####  Kp2 vs K1p2
Kp2 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TablesS5andS9/K(p2) aka KP29Anc.txt", header=TRUE))
datamatAnc <- Kp2

K1p2 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TablesS5andS9/K1(p2).txt", header=TRUE))
datamatEv1 <- K1p2

Kp2VsK1p2 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,plot.Anc=FALSE,my.guess = c(0.5, 0.6, 0.005,log(0.5)))
Kp2VsK1p2

> Kp2VsK1p2
$AncCIs.mat
                2.5%        MLE        97.5%
Beta0     -6.2793009 -3.5580018 -0.836702584
Beta1      0.7036755  1.8492449  2.994814341
Beta2     -0.2170803 -0.1056560  0.005768382
log(Beta) -1.2340802  0.1490646  1.532209362

$EvCIs.mat
                 2.5%        MLE      97.5%
Beta0     -11.5463613 -7.8105966 -4.0748318
Beta1       0.4341544  1.5938671  2.7535798
Beta2      -0.1912480 -0.1053306 -0.0194131
log(Beta) -22.3120088  7.6098497 37.5317083

$JointCIs.mat
                2.5%         MLE        97.5%
Beta0     -6.8382382 -3.86450555 -0.890772928
Beta1      0.1982041  1.30303786  2.407871633
Beta2     -0.1862350 -0.09195269  0.002329582
log(Beta) -1.9739595 -1.27396680 -0.573974090

$BIC.sep
[1] 95.13897

$BIC.joint
[1] 132.235

$Best.model
[1] "Separate dynamics is best"


####  K1p1 vs K1p1k
K1p1 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TablesS5andS9/K1(p1).txt", header=TRUE))
datamatAnc <- K1p1

K1p1k <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TablesS5andS9/K1(p1K) aka KP28_4.txt", header=TRUE))
datamatEv1 <- K1p1k

K1p1VsK1p1k <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,plot.Anc=FALSE,my.guess = c(0.5, 0.6, 0.005,log(0.5)))
K1p1VsK1p1k

$AncCIs.mat
                 2.5%          MLE       97.5%
Beta0     -3.91312403 -2.500961822 -1.08879961
Beta1      0.07776850  0.648145637  1.21852278
Beta2     -0.05501987  0.000521783  0.05606343
log(Beta)  0.14189284  1.669203268  3.19651370

$EvCIs.mat
                 2.5%         MLE       97.5%
Beta0     -7.03948268 -4.86588402 -2.69228537
Beta1      0.09073107  0.81032266  1.52991424
Beta2     -0.05532305  0.00458171  0.06448647
log(Beta)  1.19786097  2.86848324  4.53910551

$JointCIs.mat
                 2.5%         MLE       97.5%
Beta0     -4.21665761 -2.98551653 -1.75437545
Beta1      0.05632598  0.52475706  0.99318813
Beta2     -0.02811611  0.01608991  0.06029592
log(Beta)  0.40211059  1.24419088  2.08627118

$BIC.sep
[1] 133.9192

$BIC.joint
[1] 135.5445

$Best.model
[1] "Separate dynamics is best"


####  K1p1 vs Kp1
K1p1 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TablesS5andS9/K1(p1).txt", header=TRUE))
datamatAnc <- K1p1

Kp1 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TablesS5andS9/K(p1) aka KP28Anc.txt", header=TRUE))
datamatEv1 <- Kp1

K1p1VsKp1 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,plot.Anc=FALSE,my.guess = c(0.5, 0.6, 0.005,log(0.5)))
K1p1VsKp1

> K1p1VsKp1
$AncCIs.mat
                 2.5%          MLE       97.5%
Beta0     -3.91312403 -2.500961822 -1.08879961
Beta1      0.07776850  0.648145637  1.21852278
Beta2     -0.05501987  0.000521783  0.05606343
log(Beta)  0.14189284  1.669203268  3.19651370

$EvCIs.mat
                 2.5%       MLE      97.5%
Beta0       -5.832547 -3.850033  -1.867519
Beta1     -116.432491  1.714373 119.861237
Beta2      -39.096832  0.288742  39.674316
log(Beta) -317.426824 10.660825 338.748473

$JointCIs.mat
                 2.5%         MLE        97.5%
Beta0     -2.43210149 -1.21459599  0.002909507
Beta1      0.05568138  0.68347202  1.311262647
Beta2     -0.08239401 -0.01188092  0.058632168
log(Beta) -1.83703264 -1.03211002 -0.227187403

$BIC.sep
[1] 102.1923

$BIC.joint
[1] 120.1335

$Best.model
[1] "Separate dynamics is best"



####  short K2p2 vs K2p2k
K2p2 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TablesS5andS9/K2(p2).txt", header=TRUE))
datamatAnc <- K2p2[1:3,]

K2p2k <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TablesS5andS9/K2(p2K) aka KP29_2.txt", header=TRUE))
datamatEv1 <- K2p2k[1:3,]

K2p2VsK2p2k <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,plot.Anc=FALSE,my.guess = c(0.5, 0.6, 0.005,log(0.5)))
K2p2VsK2p2k

> K2p2VsK2p2k
$AncCIs.mat
                2.5%        MLE      97.5%
Beta0     -4.7163689 -4.7163689 -4.7163689
Beta1      4.3972194  4.3972194  4.3972194
Beta2     -0.6721095 -0.6721095 -0.6721095
log(Beta) 54.2315587 54.2315587 54.2315587

$EvCIs.mat
                2.5%         MLE      97.5%
Beta0     -141.41058 -13.3898544 114.630871
Beta1      -59.06088   4.9480656  68.957010
Beta2       -7.62627  -0.5146419   6.596986
log(Beta) -122.20536  11.6203831 145.446129

$JointCIs.mat
                2.5%          MLE      97.5%
Beta0     -7.5926686 -5.577100561 -3.5615325
Beta1     -0.6710967  0.543480749  1.7580582
Beta2     -0.1630585 -0.002261502  0.1585355
log(Beta)  1.4340942  5.135268806  8.8364434

$BIC.sep
[1] 41.19755

$BIC.joint
[1] 55.09787

$Best.model
[1] "Separate dynamics is best"


####  long K2p2 vs K2p2k
K2p2 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TablesS5andS9/K2(p2).txt", header=TRUE))
datamatAnc <- K2p2

K2p2k <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TablesS5andS9/K2(p2K) aka KP29_2.txt", header=TRUE))
datamatEv1 <- K2p2k

K2p2VsK2p2k <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,plot.Anc=FALSE,my.guess = c(0.5, 0.6, 0.005,log(0.5)))
K2p2VsK2p2k

> K2p2VsK2p2k
$AncCIs.mat
                 2.5%          MLE       97.5%
Beta0     -8.59568825 -5.952093735 -3.30849921
Beta1     -0.38204258  0.488255945  1.35855446
Beta2     -0.05982742  0.008216308  0.07626004
log(Beta)  9.78807988  9.795325631  9.80257138

$EvCIs.mat
                2.5%         MLE        97.5%
Beta0     -8.9883281 -6.22450120 -3.460674324
Beta1      0.2075075  1.21255221  2.217596949
Beta2     -0.1680236 -0.08556644 -0.003109293
log(Beta)  1.1389884  4.91085555  8.682722651

$JointCIs.mat
                 2.5%         MLE       97.5%
Beta0     -7.48802642 -5.51190245 -3.53577847
Beta1      0.01065724  0.69951303  1.38836881
Beta2     -0.08470728 -0.02792503  0.02885723
log(Beta)  2.10769811  3.49296693  4.87823575

$BIC.sep
[1] 93.55192

$BIC.joint
[1] 96.6796

$Best.model
[1] "Separate dynamics is best"



####  K2p2 vs Kp2
K2p2 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TablesS5andS9/K2(p2).txt", header=TRUE))
datamatAnc <- K2p2

Kp2 <- as.matrix(read.table(file="~/Documents/UFL/RESEARCH/EvaTop/HannahJordt/TablesS5andS9/K(p2) aka KP29Anc.txt", header=TRUE))
datamatEv1 <- Kp2

K2p2VsKp2 <- joint.vs.sep.fit(datamatAnc=datamatAnc, datamatEv = datamatEv1,plot.Anc=FALSE,my.guess = c(0.5, 0.6, 0.005,log(0.5)))
K2p2VsKp2

> K2p2VsKp2
$AncCIs.mat
                 2.5%          MLE       97.5%
Beta0     -8.59568825 -5.952093735 -3.30849921
Beta1     -0.38204258  0.488255945  1.35855446
Beta2     -0.05982742  0.008216308  0.07626004
log(Beta)  9.78807988  9.795325631  9.80257138

$EvCIs.mat
                2.5%        MLE        97.5%
Beta0     -6.2793009 -3.5580018 -0.836702584
Beta1      0.7036755  1.8492449  2.994814341
Beta2     -0.2170803 -0.1056560  0.005768382
log(Beta) -1.2340802  0.1490646  1.532209362

$JointCIs.mat
                2.5%         MLE       97.5%
Beta0     -4.4679043 -2.56997456 -0.67204485
Beta1     -0.1294059  0.64392514  1.41725619
Beta2     -0.1017957 -0.02894825  0.04389922
log(Beta) -1.9327163 -1.23821396 -0.54371161

$BIC.sep
[1] 96.46694

$BIC.joint
[1] 135.079

$Best.model
[1] "Separate dynamics is best"

